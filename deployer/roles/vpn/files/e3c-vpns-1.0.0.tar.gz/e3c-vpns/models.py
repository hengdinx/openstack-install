#!/usr/bin/env python
# -*- coding:utf8 -*-
#Author:liucheng
#Date:20180720
import os,sys
from oslo_config import cfg
from sqlalchemy import Column,String,create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base

BASE_PATH = os.path.dirname(os.path.abspath(__file__))
CONF_PATH = os.path.join(BASE_PATH,'conf')

db_cfg_group = cfg.OptGroup(
    name = 'database',
    title = 'database config options'
)

database_cfg_opts = [
    cfg.StrOpt('host',default='127.0.0.1',help='IP/Hostname of database server'),
    cfg.IntOpt('port',default=3306,help='Port of database server'),
    cfg.StrOpt('username',default='root',help='User of database server'),
    cfg.StrOpt('password',default='qwer1234',help='Password of DBUser'),
    cfg.StrOpt('dbname',default='e3c-vpns',help='name of database')
]

CONF = cfg.CONF
CONF.register_group(db_cfg_group)
CONF.register_opts(database_cfg_opts,db_cfg_group)

#创建对象的基类
Base = declarative_base()

#定义Router对象:
class Router(Base):
    #表的名称
    __tablename__ = 'routers'

    #表的结构
    id = Column(String(200),primary_key=True)
    name = Column(String(200))
    ha = Column(String(100))
    distributed = Column(String(100))

#初始化数据库连接
CONF(default_config_files=[os.path.join(CONF_PATH,'e3c-vpns.conf')])
dbuser = CONF.database.username
dbpass = CONF.database.password
dbhost = CONF.database.host
dbport = CONF.database.port
dbname = CONF.database.dbname
engine = create_engine("mysql+mysqldb://{dbuser}:{password}@{dbhost}:{dbport}/{dbname}"
                      .format(dbuser=dbuser,password=dbpass,dbhost=dbhost,dbport=dbport,dbname=dbname),encoding='utf-8',pool_size=100,pool_recycle=3600)

#创建DBSession 类型
DBSession = sessionmaker(bind=engine)


if __name__ == '__main__':
    Base.metadata.create_all(engine)
