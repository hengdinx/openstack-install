#!/usr/bin/env python
#-*- coding:utf-8-*-
#Author: liucheng
#date:201807180304
import json
from oslo_config import cfg
import os,sys,subprocess,time
from keystoneauth1 import identity
from keystoneauth1 import session
from neutronclient.v2_0 import client
import eventlet,greenlet
from eventlet import wsgi
import paramiko
import logging

BASE_PATH = os.path.dirname(os.path.abspath(__file__))
CONF_PATH = os.path.join(BASE_PATH,'conf')
sys.path.append(BASE_PATH)
os_auth_file_opt = cfg.StrOpt('osauth_file',default='/opt/zero/admin-openrc.sh',help='auth file of openstack')
ssh_user_opt = cfg.StrOpt('ssh_user',default='root',help='ssh user')
ssh_port_opt = cfg.IntOpt('ssh_port',default=22,help='ssh port')
log_path_opt = cfg.StrOpt('log_path',default='/var/log/e3c/e3c-vpns.log',help='log path of e3c-vpns')
debug_opt = cfg.StrOpt('debug',default='debug',help='logger level')
#创建对象CONF,用来充当容器
CONF = cfg.CONF
#注册含有多个配置项模式
CONF.register_opt(os_auth_file_opt)
CONF.register_opt(ssh_user_opt)
CONF.register_opt(ssh_port_opt)
CONF.register_opt(log_path_opt)
CONF.register_opt(debug_opt)
CONF(default_config_files=[os.path.join(CONF_PATH, 'e3c-vpns.conf')])

log_path = CONF.log_path
debug = CONF.debug

logger = logging.getLogger(__name__)
logger.propagate = False
fm = logging.Formatter('[%(asctime)s] %(levelname)s %(message)s')
fh = logging.handlers.TimedRotatingFileHandler(log_path, 'H', 24, 7)
fh.setFormatter(fm)
sh =logging.StreamHandler()
sh.setFormatter(fm)
logger.addHandler(fh)
logger.addHandler(sh)
if debug == 'False' or debug == 'false':
    logger.setLevel(logging.WARNING)
elif debug == 'True' or debug == 'true':
    logger.setLevel(logging.INFO)

def ssh_execute_cmd(hostname, cmd_str):
    hostname = hostname
    ssh_port = CONF.ssh_port
    ssh_user = CONF.ssh_user
    ssh = paramiko.SSHClient()
    ssh.load_system_host_keys()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    privatekey = os.path.expanduser('~/.ssh/id_rsa')
    key = paramiko.RSAKey.from_private_key_file(privatekey)
    ssh.connect(hostname, port=ssh_port, username=ssh_user)
    stdin, stdout, stderr = ssh.exec_command(cmd_str)
    stderr = stderr.read()
    channel = stdout.channel
    status = channel.recv_exit_status()
    if not stderr:
        return (stdout.readlines(),status)
    else:
        return None

def execute_cmd(cmd_str):
    p = subprocess.Popen(cmd_str,shell=True,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    out,err = p.communicate()
    return dict(rc=p.returncode,stdout=out,stderr=err)

class OpenstackOperate(object):
    def __init__(self,auth_file):
        self.auth_file = auth_file
        self.auth_info = self.get_keystone_cred(self.auth_file)
        
    def get_keystone_cred(self,auth_file):
        try:
            f = open(auth_file,'r')
            for line in f.readlines():
                line = line.strip()
                if not len(line) or line.startswith('#'):
                    continue
                if 'OS_USERNAME=' in line:
                    os_username = line.split('=')[1]
                if 'OS_PASSWORD=' in line:
                    os_password = line.split('=')[1]
                if 'OS_AUTH_URL=' in line:
                    os_auth_url = line.split('=')[1]
                if 'OS_PROJECT_NAME=' in line:
                    os_project_name = line.split('=')[1]
                if 'OS_USER_DOMAIN_NAME=' in line:
                    os_user_domain_name = line.split('=')[1]
                if 'OS_PROJECT_DOMAIN_NAME=' in line:
                    os_project_domain_name = line.split('=')[1]
            f.close()
            return {'os_username':os_username,'os_password':os_password,'os_auth_url':os_auth_url,'os_project_name':os_project_name, \
                'os_user_domain_name':os_user_domain_name,'os_project_domain_name':os_project_domain_name}
        except IOError as e:
            logger.warning(e)
            return {}
    def neutron_auth(self):
        if self.auth_file:
            username = self.auth_info.get('os_username')
            password = self.auth_info.get('os_password')
            project_name = self.auth_info.get('os_project_name')
            project_domain_id = self.auth_info.get('os_user_domain_name').lower()
            user_domain_id = self.auth_info['os_project_domain_name'].lower()
            auth_url = self.auth_info.get('os_auth_url')
            try:
                auth = identity.Password(auth_url=auth_url,username=username,password=password,project_name=project_name,\
                                         project_domain_id=project_domain_id,user_domain_id=user_domain_id)
                sess = session.Session(auth=auth)
                Client = client.Client(session=sess)
                return Client
            except Exception as e:
                logger.warning(e)
                return None

    def get_router_detail(self,id):
        try:
            neutron = self.neutron_auth()
            router = neutron.show_router(id)['router']
            ha = router.get('ha')
            if not ha:
                ha = 'False'
            else:
                ha = 'True'
            distributed = router.get('distributed')
            if not distributed:
                distributed = 'False'
            else:
                distributed = 'True'
            external_gateway_info = router.get('external_gateway_info')
            if external_gateway_info:
                external_gateway_ip = external_gateway_info['external_fixed_ips'][0]['ip_address']
                external_subnet_id = external_gateway_info['external_fixed_ips'][0]['subnet_id']
                return {'router': {'ha': ha, 'distributed': distributed, 'external_gateway_ip': external_gateway_ip,
                                   'external_subnet_id': external_subnet_id}}
            else:
                return {'router': {'ha': ha, 'distributed': distributed,'external_gateway_ip':None,
                                   'external_subnet_id':None}}
        except Exception as e:
            logging.warning(e)
            return {}

    def get_all_subnets(self,id):
        self.subnets = {}
        try:
            neutron = self.neutron_auth()
            ports = neutron.list_ports()['ports']
            for port in ports:
                if port.get('device_owner') == 'network:router_interface'or port.get('device_owner') == 'network:router_interface_distributed':
                    subnet_id = port.get('fixed_ips')[0]['subnet_id']
                    self.subnets[subnet_id] = {'subnet_id':subnet_id}
            if self.subnets:
                for subnet in self.subnets.values():
                    subnet_id = subnet.get('subnet_id')
                    cmd_str = 'source {auth_file} && neutron router-port-list {router_id} | grep {subnet_id}'\
                        .format(auth_file=self.auth_file,router_id=id,subnet_id=subnet_id)
                    ret = execute_cmd(cmd_str)
                    if ret['rc'] != 0:
                        self.subnets.pop(subnet_id)
                return self.subnets
        except Exception as e:
            logger.warning(e)
            return {}

    def get_all_cidr(self,id):
        self.cidrs = {}
        try:
            neutron = self.neutron_auth()
            sub_pools = neutron.list_subnets().get('subnets')
            if self.get_all_subnets(id):
                subnets = self.get_all_subnets(id).values()
                for subnet in subnets:
                    subnet_id = subnet['subnet_id']
                    for pool in sub_pools:
                        id = pool.get('id')
                        if subnet_id == id:
                            cidr_info = pool.get('cidr')
                            self.cidrs[id] = {'cidr':cidr_info}
                return self.cidrs
            return {}
        except Exception as e:
            logger.warning(e)
            return {}

    def get_all_agents(self,id):
        self.agents = {}
        try:
            neutron = self.neutron_auth()
            l3_agents = neutron.list_l3_agent_hosting_routers(id).get('agents')
            for agent in l3_agents:
                agent_id = agent.get('id')
                agent_host = agent.get('host')
                agent_ha_state = agent['ha_state']
                self.agents[agent_id] = {'host':agent_host,'ha_state':agent_ha_state}
            return self.agents
        except Exception,e:
            logger.warning(e)
            return {}

    def get_external_cidr(self,subnet_id):
        try:
            neutron = self.neutron_auth()
            all_subnets = neutron.list_subnets().get('subnets')
            for subnet in all_subnets:
                id = subnet.get('id')
                if subnet_id == id:
                    cidr = subnet.get('cidr')
                    return cidr
        except Exception,e:
            logger.warning(e)
            return {}

class WSGIServer(object):
    def __init__(self,app,host='0.0.0.0',port=8201):
        self._pool = eventlet.GreenPool(10)
        self.app = app
        self._socket = eventlet.listen((host,port),backlog=10)
        (self.host,self.port) = self._socket.getsockname()
        print("WSGI-Server Listening on %(host)s:%(port)s" % self.__dict__)
    def start(self):
        self._wsgiserver = eventlet.spawn(eventlet.wsgi.server,self._socket,self.app,custom_pool=self._pool)
    def stop(self):
        if self._wsgiserver is not None:
            self._pool.resize(0)
            self._wsgiserver.kill()
    def wait(self):
        try:
            self._wsgiserver.wait()
        except greenlet.GreenletExit,e:
            print("WSGI server has stopped.")
