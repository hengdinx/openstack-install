from webob import Request,Response
import json
from webob.dec import wsgify
import webob.exc
from models import DBSession,Router
import utils
from oslo_config import cfg
import os,sys,Service
import logging,traceback

BASE_PATH = os.path.dirname(os.path.abspath(__file__))
CONF_PATH = os.path.join(BASE_PATH,'conf')
sys.path.append(BASE_PATH)
os_auth_file_opt = cfg.StrOpt('osauth_file',default='/opt/zero/admin-openrc.sh',help='auth file of openstack')
log_path_opt = cfg.StrOpt('log_path',default='/var/log/e3c/e3c-vpns.log',help='log path of e3c-vpns')
debug_opt = cfg.StrOpt('debug',default='debug',help='logger level')

CONF = cfg.CONF
CONF.register_opt(os_auth_file_opt)
CONF.register_opt(log_path_opt)
CONF.register_opt(debug_opt)
CONF(default_config_files=[os.path.join(CONF_PATH,'e3c-vpns.conf')])
osauth_file = CONF.osauth_file
log_path = CONF.log_path
debug = CONF.debug

logger = logging.getLogger(__name__)
logger.propagate = False
fm = logging.Formatter('[%(asctime)s] %(levelname)s %(message)s')
fh = logging.handlers.TimedRotatingFileHandler(log_path, 'H', 24, 7)
fh.setFormatter(fm)
sh =logging.StreamHandler()
sh.setFormatter(fm)
logger.addHandler(fh)
logger.addHandler(sh)
if debug == 'False' or debug == 'false':
    logger.setLevel(logging.WARNING)
elif debug == 'True' or debug == 'true':
    logger.setLevel(logging.INFO)

class ShowVersion():
    def __init__(self,version):
        self.version = version
    def __call__(self,environ,start_response):
        res = Response()
        res.status = '200 OK'
        res.content_type = "text/plain"
        content = []
        content.append("%s\n" % self.version)
        res.body = '\n'.join(content)
        return res(environ,start_response)
    @classmethod
    def factory(cls,global_conf,**kwargs):
        return ShowVersion('e3c-vpns version is %s '% kwargs['version'])

class Controller(object):
    @wsgify
    def create(self,req,*args,**kwargs):
        try:
            name = kwargs['body']['name']
            id = kwargs['body']['id']
            if name and id:
                op = utils.OpenstackOperate(osauth_file)
                ret = op.get_router_detail(id)
                if ret:
                    ha = ret.get('router')['ha']
                    distributed = ret.get('router')['distributed']
                    session = DBSession()
                    router = Router(id=id,name=name,ha=ha,distributed=distributed)
                    session.add(router)
                    session.commit()
                    session.close()
                    monitor_server = Service.MonitorService()
                    monitor_server.add_ip_route()
                    return {'result' : 'true'}
        except Exception,e:
            logging.warning(traceback.format_exc())
            return {'result':'false'}
    
    @wsgify
    def show(self,req,id):
        if id:
            session = DBSession()
            result = session.query(Router)
            router = result.get(id)
            if router:
                return {'router':{'id':router.id,'name':router.name}}
            session.close()
        return {'router' : {}}
    
    @wsgify
    def index(self,req):
        self.routers = {}
        session = DBSession()
        result = session.query(Router)
        if result.first():
            for router in result:
                self.routers[router.id] = {'id':router.id,'name':router.name}
            return {'routers':self.routers.values()}
        session.close()
        return {'routers' : {}}
    
    @wsgify
    def delete(self,req,id):
        try:
            if id:
                session = DBSession()
                result = session.query(Router)
                router = result.get(id)
                router_ha = router.ha
                router_distributed = router.distributed
                if router:
                    monitor_server = Service.MonitorService()
                    result = monitor_server.del_ip_route(router_id=id,router_ha=router_ha,router_distributed=router_distributed)
                    if result['result'] == 'true':
                        session.delete(router)
                        session.commit()
                        session.close()
                        return {'result':'true'}
        except Exception,e:
            logger.warning(traceback.format_exc())
            return {'result':'false'}

class JSONRequestDeserializer(object):
    def has_body(self,request):
        """
        Returns whether a Webob.Request object will possess an entity body.
        :param request: Webob.Request object
        """
        if 'transfer-encoding' in request.headers:
            return True
        elif request.content_length > 0:
            return True
        return False

    def from_json(self,datastring):
        try:
            return json.loads(datastring)
        except ValueError:
            msg = ('Malformed JSON in request body.')
            logging.warning(webob.exc.HTTPBadRequest(explanation=msg))
    
    def default(self,request):
        if self.has_body(request):
            return {'body':self.from_json(request.body)}
        else:
            return {}

class JSONResponseSerializer(object):
    def to_json(self,data):
        return json.dumps(data)
    
    def default(self,response,result):
        response.content_type = 'application/json'
        response.body = self.to_json(result)

class Resource(object):
    def __init__(self,controller,deserializer=None,serializer=None):
        self.controller = controller
        self.serializer = serializer or JSONResponseSerializer()
        self.deserializer = deserializer or JSONRequestDeserializer()

    @wsgify
    def __call__(self,request):
        """WSGI method that controls (de)serialization and method dispatch."""
        action_args = self.get_action_args(request.environ)
        logger.info('action is {}'.format(action_args))
        action = action_args.pop('action',None)
        
        deserialized_request = self.dispatch(self.deserializer,action,request)
        action_args.update(deserialized_request)
        action_result = self.dispatch(self.controller,action,request,**action_args)
        
        try:
            response = Response(request=request)
            self.dispatch(self.serializer,action,response,action_result)
            return response
        except webob.exc.HTTPException as e:
            return e
        except Exception:
            return action_result

    def dispatch(self,obj,action,*args,**kwargs):
        """Find action-specific method on self and call it."""
        try:
            method = getattr(obj,action)
        except AttributeError:
            method = getattr(obj,'default')
      
        return method(*args,**kwargs)
    
    def get_action_args(self,request_environment):
        try:
            args = request_environment['wsgiorg.routing_args'][1].copy()
        except Exception:
            return {}
        
        try:
            del args['controller']
        except KeyError,e:
            raise
    
        try:
            del args['format']
        except KeyError:
            pass

        return args
