#!/usr/bin/env python
#-*- coding:utf-8 -*-
#Author:liucheng
#Date:20180720
import os
from paste.deploy import loadapp
import threading
import multiprocessing
import logging,traceback
from oslo_config import cfg
import time,utils,models,socket,IPy

BASE_PATH = os.path.dirname(os.path.abspath(__file__))
CONF_PATH = os.path.join(BASE_PATH,'conf')
os_auth_file_opt = cfg.StrOpt('osauth_file',default='/opt/zero/admin-openrc.sh',help='auth file of openstack')
log_path_opt = cfg.StrOpt('log_path',default='/var/log/e3c/e3c-vpns.log',help='log path of e3c-vpns')
debug_opt = cfg.StrOpt('debug',default='debug',help='logger level')
common_opts = [
    cfg.StrOpt('bind_host',default='0.0.0.0',help='IP address to listen'),
    cfg.IntOpt('bind_port',default='8201',help='Port to listen')
]

#创建对象CONF，用来充当容器
CONF = cfg.CONF
#注册含有多个配置项模式
CONF.register_opts(common_opts)
CONF.register_opt(os_auth_file_opt)
CONF.register_opt(log_path_opt)
CONF.register_opt(debug_opt)
CONF(default_config_files=[os.path.join(CONF_PATH, 'e3c-vpns.conf')])

log_path = CONF.log_path
debug = CONF.debug

logger = logging.getLogger(__name__)
logger.propagate = False
fm = logging.Formatter('[%(asctime)s] %(levelname)s %(message)s')
fh = logging.handlers.TimedRotatingFileHandler(log_path, 'H', 24, 7)
fh.setFormatter(fm)
sh =logging.StreamHandler()
sh.setFormatter(fm)
logger.addHandler(fh)
logger.addHandler(sh)
if debug == 'False' or debug == 'false':
    logger.setLevel(logging.WARNING)
elif debug == 'True' or debug == 'true':
    logger.setLevel(logging.INFO)

class WSGIService(object):
    def __init__(self):
        bind_host = CONF.bind_host
        bind_port = CONF.bind_port
        paste_config = os.path.join(CONF_PATH, "e3c-vpns_paste.ini")
        appname = "main"
        self.wsgi_app = loadapp("config:%s" % os.path.abspath(paste_config), appname)
        self.server = utils.WSGIServer(self.wsgi_app,bind_host,bind_port)
    def start(self):
        self.server.start()
    def wait(self):
        self.server.wait()
    def stop(self):
        self.server.stop()

class MonitorService(object):
    def __init__(self):
        self.routers = {}
        self.org_cidrs = {}
        self.new_cidrs = {}
        self.os_auth_file = CONF.osauth_file

    def scan_resource(self):
        try:
            session = models.DBSession()
            result = session.query(models.Router)
            session.close()
            if result.first():
                for router in result:
                    self.routers[router.id] = {'id':router.id,'name':router.name,'ha':router.ha,'distributed':router.distributed}
                return {'routers':self.routers.values()}
            else:
                return {}
        except Exception,e:
            return {}

    def get_host_info(self,agents,external_subnet_id):
        op = utils.OpenstackOperate(self.os_auth_file)
        net = op.get_external_cidr(external_subnet_id)
        if net:
            external_ips = IPy.IP(net)
        all_agents_ip_info = {}
        if agents:
            for agent in agents.values():
                host = agent['host']
                cmd_str = 'ip a | grep br-ex | wc -l'
                res = utils.ssh_execute_cmd(host,cmd_str)
                if int(res[0][0]) > 0:
                    cmd_str = "ip a | grep br-ex | grep 'inet' | awk '{print $2}' | awk -F '/' '{print $1}'"
                    res = utils.ssh_execute_cmd(host,cmd_str)
                    external_ip = res[0][0]
                    if external_ip in external_ips:
                        ip = external_ip
                        all_agents_ip_info[host] = ip
                    else:
                        ip = socket.gethostbyname(host)
                        all_agents_ip_info[host] = ip
                else:
                    ip = socket.gethostbyname(host)
                    all_agents_ip_info[host] = ip
            return all_agents_ip_info

    def get_host_openvpn_info(self,agents):
        if agents:
            all_agents_openvpn_info = {}
            for agent in agents.values():
                host = agent['host']
                cmd_str = "grep '169.255' /var/lib/docker/containers/openvpn-server/server.conf"
                server_net = utils.ssh_execute_cmd(host,cmd_str)[0]
                if server_net:
                    net = server_net[0].strip().split('255.255.240.0')[0].strip().split('server')[-1].strip()
                    if net == '169.255.0.0':
                        cidr = '169.255.0.0/20'
                    elif net == '169.255.16.0':
                        cidr = '169.255.16.0/20'
                    elif net == '169.255.32.0':
                        cidr = '169.255.32.0/20'
                    all_agents_openvpn_info[host] = cidr
            return all_agents_openvpn_info

    def add_single_router_ip_route(self,router_id=None,agents=None,external_subnet_id=None):
        op = utils.OpenstackOperate(self.os_auth_file)
        net = op.get_external_cidr(external_subnet_id)
        if net:
            external_ips = IPy.IP(net)
        cmd_str = 'ip a | grep br-ex | wc -l'
        res = utils.execute_cmd(cmd_str)
        if int(res['stdout']) > 0:
            cmd_str = "ip a | grep br-ex | grep 'inet' | awk '{print $2}' | awk -F '/' '{print $1}'"
            res = utils.execute_cmd(cmd_str)
            external_ip = res['stdout']
            if external_ip in external_ips:
                host_ip = external_ip
                logger.info('ip of host_ip is %s' % host_ip)
            else:
                hostname = agents.values()[0]['host']
                host_ip = socket.gethostbyname(hostname)
                logger.info('ip of host_ip is %s' % host_ip)
        else:
            hostname = agents.values()[0]['host']
            host_ip = socket.gethostbyname(hostname)
            logger.info('ip of host_ip is %s' % host_ip)
        if host_ip:
            netns = 'qrouter-{}'.format(router_id)
            cmd_str = 'ip netns exec {netns} ip route | grep 169.255.0.0/20' \
                .format(netns=netns)
            ret = utils.execute_cmd(cmd_str)
            if ret['rc'] != 0:
                cmd_str = 'ip netns exec {netns} ip route add 169.255.0.0/20 via {host_ip}' \
                    .format(netns=netns, host_ip=host_ip)
                ret = utils.execute_cmd(cmd_str)
                if ret['rc'] == 0:
                    logger.info('add route of router {} to 169.255.0.0/20 successful!'.format(router_id))
                else:
                    logger.info('add route of router {} to 169.255.0.0/20 failed!'.format(router_id))
            else:
                logger.info('Router {} to 169.255.0.0/20 route already exists.'.format(router_id))
        else:
            logger.warning('please add Host/IP to /etc/hosts')


    def del_single_router_ip_route(self,router_id=None,agents=None,external_subnet_id=None):
        op = utils.OpenstackOperate(self.os_auth_file)
        net = op.get_external_cidr(external_subnet_id)
        if net:
            external_ips = IPy.IP(net)
        cmd_str = 'ip a | grep br-ex | wc -l'
        res = utils.execute_cmd(cmd_str)
        if int(res['stdout']) > 0:
            cmd_str = "ip a | grep br-ex | grep 'inet' | awk '{print $2}' | awk -F '/' '{print $1}'"
            res = utils.execute_cmd(cmd_str)
            external_ip = res['stdout']
            if external_ip in external_ips:
                host_ip = external_ip
                logger.info('ip of host_ip is %s' % host_ip)
            else:
                hostname = agents.values()[0]['host']
                host_ip = socket.gethostbyname(hostname)
                logger.info('ip of host_ip is %s' % host_ip)
        else:
            hostname = agents.values()[0]['host']
            host_ip = socket.gethostbyname(hostname)
            logger.info('ip of host_ip is %s' % host_ip)
        if host_ip:
            netns = 'qrouter-{}'.format(router_id)
            cmd_str = 'ip netns exec {netns} ip route | grep 169.255.0.0/20' \
                .format(netns=netns)
            ret = utils.execute_cmd(cmd_str)
            if ret['rc'] == 0:
                cmd_str = 'ip netns exec {netns} ip route del 169.255.0.0/20 via {host_ip}' \
                    .format(netns=netns, host_ip=host_ip)
                ret = utils.execute_cmd(cmd_str)
                if ret['rc'] == 0:
                    logger.info('del route to 169.255.0.0/20 for router {} successful'.format(router_id))
                else:
                    logger.info('del route to 169.255.0.0/20 for router {} failed'.format(router_id))
            else:
                logger.info('Router {} to 169.255.0.0/20 router already exists.'.format(router_id))
        else:
            logger.warning('please add Host/IP to /etc/hosts')

    def add_single_dvrrouter_ip_route(self,router_id=None,agents=None):
        hostname = agents.values()[0]['host']
        host_ip = socket.gethostbyname(hostname)
        if host_ip:
            netns = 'snat-{}'.format(router_id)
            cmd_str = 'ip netns exec {netns} ip route | grep 169.255.0.0/20'\
                .format(netns=netns)
            ret = utils.execute_cmd(cmd_str)
            if ret['rc'] != 0:
                cmd_str = 'ip netns exec {netns} ip route add 169.255.0.0/20 via {host_ip}'\
                    .format(netns=netns,host_ip=host_ip)
                ret = utils.execute_cmd(cmd_str)
                if ret['rc'] == 0:
                    logger.info('add route to 169.255.0.0/20 for router {} successful'.format(router_id))
                else:
                    logger.info('add route to 169.255.0.0/20 for router {} failed'.format(router_id))
            else:
                logger.info('Router {} to 169.255.0.0/20 route already exists.'.format(router_id))
        else:
            logger.warning('please add Host/IP to /etc/hosts ')

    def del_single_dvrrouter_ip_route(self,router_id=None,agents=None):
        hostname = agents.values()[0]['host']
        host_ip = socket.gethostbyname(hostname)
        if host_ip:
            netns = 'snat-{}'.format(router_id)
            cmd_str = 'ip netns exec {netns} ip route | grep 169.255.0.0/20'\
                .format(netns=netns)
            ret = utils.execute_cmd(cmd_str)
            if ret['rc'] == 0:
                cmd_str = 'ip netns exec {netns} ip route del 169.255.0.0/20 via {host_ip}'\
                    .format(netns=netns,host_ip=host_ip)
                ret = utils.execute_cmd(cmd_str)
                if ret['rc'] == 0:
                    logger.info('del router to 169.255.0.0/20 for router {} successful'.format(router_id))
                else:
                    logger.info('del router to 169.255.0.0/20 for router {} failed'.format(router_id))
            else:
                logger.info('Router {} to 169.255.0.0/20 route does not exists.')
        else:
            logger.warning('please add Host/IP to /etc/hosts')

    def add_multi_dvrrouter_ip_route(self,router_id=None,agents=None,external_subnet_id=None):
        master_host_list = []
        netns = 'snat-{}'.format(router_id)
        all_agent_info = self.get_host_info(agents,external_subnet_id)
        all_host_openvpn_info = self.get_host_openvpn_info(agents)
        for agent in agents.values():
            if agent['ha_state'] == 'active':
                master_host_list.append(agent['host'])
        for agent in agents.values():
            host = agent['host']
            host_ip = all_agent_info[host]
            host_openvpn_net = all_host_openvpn_info[host]
            for master_host in master_host_list:
                cmd_str = 'ip netns exec {netns} ip route | grep {server_info}' \
                    .format(netns=netns, server_info=host_openvpn_net)
                ret = utils.ssh_execute_cmd(master_host,cmd_str)
                if ret[1] != 0:
                    cmd_str = 'ip netns exec {netns} ip route add {server_info} via {host_ip}' \
                        .format(netns=netns, server_info=host_openvpn_net,host_ip=host_ip)
                    ret = utils.ssh_execute_cmd(master_host,cmd_str)
                    if ret[1] == 0:
                        logger.info('{}添加路由器{}到{}的路由成功'.format(master_host,router_id,host_openvpn_net))
                    else:
                        logger.info('{}添加路由器{}到{}的路由失败'.format(master_host,router_id,host_openvpn_net))
                else:
                    logger.info('{}的路由器{}到{}路由已存在.'.format(master_host,router_id,host_openvpn_net))

    def del_multi_dvrrouter_ip_route(self,router_id=None,agents=None,external_subnet_id=None):
        master_host_list = []
        netns = 'snat-{}'.format(router_id)
        all_agent_info = self.get_host_info(agents,external_subnet_id)
        all_host_openvpn_info = self.get_host_openvpn_info(agents)
        for agent in agents.values():
            if agent['ha_state'] == 'active':
                master_host_list.append(agent['host'])
        for agent in agents.values():
            host = agent['host']
            host_ip = all_agent_info[host]
            host_openvpn_net = all_host_openvpn_info[host]
            for master_host in master_host_list:
                cmd_str = 'ip netns exec {netns} ip route | grep {server_info}' \
                    .format(netns=netns, server_info=host_openvpn_net)
                ret = utils.ssh_execute_cmd(master_host,cmd_str)
                if ret[1] == 0:
                    cmd_str = 'ip netns exec {netns} ip route del {server_info} via {host_ip}' \
                        .format(netns=netns, server_info=host_openvpn_net,host_ip=host_ip)
                    ret = utils.ssh_execute_cmd(master_host,cmd_str)
                    if ret[1] == 0:
                        logger.info('{}删除路由器{}到{}的路由成功'.format(master_host,router_id,host_openvpn_net))
                    else:
                        logger.info('{}删除路由器{}到{}的路由失败'.format(master_host,router_id,host_openvpn_net))
                else:
                    logger.info('{}的路由器{}到{}路由不存在.'.format(master_host,router_id,host_openvpn_net))

    def update_single_openvpn_conf(self,cidr):
        IP = IPy.IP(cidr)
        net =IP.strNormal(2).split('/')
        new_net = '{} {}'.format(net[0],net[1])
        cmd_str = "grep '{}' /var/lib/docker/containers/openvpn-server/server.conf".format(new_net)
        ret = utils.execute_cmd(cmd_str)
        if ret['rc'] != 0:
            cmd_str = "echo 'push \"route {}\"' >> /var/lib/docker/containers/openvpn-server/server.conf".format(new_net)
            rt = utils.execute_cmd(cmd_str)
            cmd_str = "docker stop openvpn-server && docker start openvpn-server"
            rt = utils.execute_cmd(cmd_str)
            if rt['rc'] == 0:
                logger.info('openvpn-server 配置更新成功')

    def del_single_openvpn_conf(self,cidr):
        IP = IPy.IP(cidr)
        net =IP.strNormal(2).split('/')
        new_net = net[0]
        cmd_str = "sed -i '/{}/d' /var/lib/docker/containers/openvpn-server/server.conf".format(new_net)
        rt = utils.execute_cmd(cmd_str)
        cmd_str = "docker stop openvpn-server && docker start openvpn-server"
        rt = utils.execute_cmd(cmd_str)
        if rt['rc'] == 0:
            logger.info('openvpn-server 记录删除成功')

    def update_multi_openvpn_conf(self,host,cidr):
        IP =IPy.IP(cidr)
        net = IP.strNormal(2).split('/')
        new_net = '{} {}'.format(net[0],net[1])
        cmd_str = "grep '{}' /var/lib/docker/containers/openvpn-server/server.conf".format(new_net)
        ret = utils.ssh_execute_cmd(host,cmd_str)
        if ret[1] != 0:
            cmd_str = "echo 'push \"route {}\"' >> /var/lib/docker/containers/openvpn-server/server.conf".format(new_net)
            rt = utils.ssh_execute_cmd(host,cmd_str)
            cmd_str = "docker stop openvpn-server && docker start openvpn-server"
            rt = utils.ssh_execute_cmd(host,cmd_str)
            if rt[1] == 0:
                logger.info('{} openvpn-server 配置更新成功'.format(host))

    def del_multi_openvpn_conf(self,host,cidr):
        IP =IPy.IP(cidr)
        net = IP.strNormal(2).split('/')
        new_net = net[0]
        cmd_str = "sed -i '/{}/d' /var/lib/docker/containers/openvpn-server/server.conf".format(new_net)
        rt = utils.ssh_execute_cmd(host,cmd_str)
        cmd_str = "docker stop openvpn-server && docker start openvpn-server"
        rt = utils.ssh_execute_cmd(host,cmd_str)
        if rt[1] == 0:
            logger.info('{} openvpn-server 记录删除成功'.format(host))

    def add_single_host_route(self,external_gateway_ip=None,cidr=None,router_id=None):
        net = cidr['cidr']
        cmd_str = 'ip route show table 10| grep {}'.format(net)
        ret = utils.execute_cmd(cmd_str)
        if ret['rc'] != 0:
            cmd_str = 'ip route add {cidr} via {gateway_ip} table 10' \
                .format(cidr=net, gateway_ip=external_gateway_ip)
            ret = utils.execute_cmd(cmd_str)
            if ret['rc'] == 0:
                logger.info('添加{}到路由器{}的路由成功'.format(net, router_id))
                self.update_single_openvpn_conf(net)
            else:
                logger.info('添加{}到路由器{}的路由失败'.format(net, router_id))
        else:
            logger.info('{}路由已存在.'.format(net))

    def del_single_host_route(self,external_gateway_ip=None,router_id=None,cidr=None):
        net = cidr['cidr']
        cmd_str = 'ip route show table 10| grep {}'.format(net)
        ret = utils.execute_cmd(cmd_str)
        if ret['rc'] == 0:
            cmd_str = 'ip route del {cidr} via {gateway_ip} table 10' \
                .format(cidr=net, gateway_ip=external_gateway_ip)
            ret = utils.execute_cmd(cmd_str)
            if ret['rc'] == 0:
                logger.info('删除{}到路由器{}的路由成功'.format(cidr['cidr'],router_id))
                self.del_single_openvpn_conf(net)
            else:
                logger.info('删除{}到路由器{}的路由失败'.format(cidr['cidr'],router_id))
        else:
            logger.info('{}路由不存在.'.format(net))

    def add_single_dvrhost_route(self,external_gateway_ip=None,cidr=None,router_id=None):
        net = cidr['cidr']
        cmd_str = 'ip route show table 10| grep {}'.format(net)
        ret = utils.execute_cmd(cmd_str)
        if ret['rc'] != 0:
            cmd_str = 'ip route add {cidr} via {gateway_ip} table 10' \
                .format(cidr=net, gateway_ip=external_gateway_ip)
            ret = utils.execute_cmd(cmd_str)
            if ret['rc'] == 0:
                logger.info('添加{}到路由器{}的路由成功'.format(net, router_id))
                self.update_single_openvpn_conf(net)
            else:
                logger.info('添加{}到路由器{}的路由失败'.format(net, router_id))
        else:
            logger.info('{}路由已存在.'.format(net))

    def del_single_dvrhost_route(self,external_gateway_ip=None,cidr=None,router_id=None):
        net = cidr['cidr']
        cmd_str = 'ip route show table 10| grep {}'.format(net)
        ret = utils.execute_cmd(cmd_str)
        if ret['rc'] != 0:
            cmd_str = 'ip route add {cidr} via {gateway_ip} table 10' \
                .format(cidr=net, gateway_ip=external_gateway_ip)
            ret = utils.execute_cmd(cmd_str)
            if ret['rc'] == 0:
                logger.info('添加{}到路由器{}的路由成功'.format(net, router_id))
                self.del_single_openvpn_conf(net)
            else:
                logger.info('添加{}到路由器{}的路由失败'.format(net, router_id))
        else:
            logger.info('{}路由不存在.'.format(net))

    def add_multi_dvrhost_route(self,external_gateway_ip=None,cidr=None,router_id=None,agents=None):
        net = cidr['cidr']
        for agent in agents.values():
            host = agent['host']
            cmd_str = 'ip route show table 10| grep {}'.format(net)
            ret = utils.ssh_execute_cmd(host,cmd_str)
            if ret[1] != 0:
                cmd_str = 'ip route add {cidr} via {gateway_ip} table 10' \
                    .format(cidr=net, gateway_ip=external_gateway_ip)
                ret = utils.ssh_execute_cmd(host,cmd_str)
                if ret[1] == 0:
                    logger.info('{}添加{}到路由器{}的路由成功'.format(host,net, router_id))
                    self.update_multi_openvpn_conf(host,net)
                else:
                    logger.info('{}添加{}到路由器{}的路由失败'.format(host,net, router_id))
            else:
                logger.info('{}到路由器{}的{}路由已存在.'.format(host,router_id,net))

    def del_multi_dvrhost_route(self,external_gateway_ip=None,cidr=None,router_id=None,agents=None):
        net = cidr['cidr']
        for agent in agents.values():
            host = agent['host']
            cmd_str = 'ip route show table 10| grep {}'.format(net)
            ret = utils.ssh_execute_cmd(host,cmd_str)
            if ret[1] == 0:
                cmd_str = 'ip route del {cidr} via {gateway_ip} table 10' \
                    .format(cidr=net, gateway_ip=external_gateway_ip)
                ret = utils.ssh_execute_cmd(host,cmd_str)
                if ret[1] == 0:
                    logger.info('{}删除{}到路由器{}的路由成功'.format(host,net, router_id))
                    self.del_multi_openvpn_conf(host,net)
                else:
                    logger.info('{}删除{}到路由器{}的路由失败'.format(host,net, router_id))
            else:
                logger.info('{}到路由器{}的{}路由不存在.'.format(host,router_id,net))

    def add_ip_route(self):
        routers = self.scan_resource()
        if routers:
            for router in routers['routers']:
                router_id = router['id']
                router_ha = router['ha']
                router_distributed = router['distributed']
                op = utils.OpenstackOperate(self.os_auth_file)
                router_detail = op.get_router_detail(router_id)
                if router_detail:
                    external_gateway_ip = router_detail['router']['external_gateway_ip']
                    external_subnet_id = router_detail['router']['external_subnet_id']
                agents = op.get_all_agents(router_id)
                cidrs = op.get_all_cidr(router_id)
                if agents and cidrs:
                    if len(agents.values()) == 1 and router_ha == 'False' and router_distributed == 'False':
                        logger.info('当前网络节点未启用HA，路由器{}模式为传统模式'.format(router_id))
                        if external_gateway_ip:
                            self.org_cidrs[router_id] = cidrs.values()
                            logger.info('org_cidrs of router {} is {}'.format(router_id,self.org_cidrs[router_id]))
                            for cidr in cidrs.values():
                                self.add_single_host_route(external_gateway_ip=external_gateway_ip,cidr=cidr,router_id=router_id)
                            self.add_single_router_ip_route(router_id=router_id,agents=agents,external_subnet_id=external_subnet_id)
                        else:
                            logger.warning('please add gateway ip of router {}'.format(router_id))
                    elif len(agents) == 1 and router_ha == 'False' and router_distributed == 'True':
                        logger.info('当前网络节点未启用HA,路由器{}模式为DVR模式'.format(router_id))
                        if external_gateway_ip:
                            self.org_cidrs[router_id] = cidrs.values()
                            logger.info('org_cidrs of router {} is {}'.format(router_id,self.org_cidrs[router_id]))
                            for cidr in cidrs.values():
                                self.add_single_dvrhost_route(external_gateway_ip=external_gateway_ip, cidr=cidr,router_id=router_id)
                            self.add_single_dvrrouter_ip_route(router_id=router_id,agents=agents)
                        else:
                            logger.warning('please add gateway ip of router {}'.format(router_id))
                    elif len(agents) >= 1 and router_ha == 'True' and router_distributed == 'True':
                        logger.info('当前网络节点已启用HA，路由器{}模式为DVR模式'.format(router_id))
                        if external_gateway_ip:
                            self.org_cidrs[router_id] = cidrs.values()
                            logger.info('org_cidrs of router {} is {}'.format(router_id,self.org_cidrs[router_id]))
                            for cidr in cidrs.values():
                                self.add_multi_dvrhost_route(external_gateway_ip=external_gateway_ip,cidr=cidr,router_id=router_id,agents=agents)
                            self.add_multi_dvrrouter_ip_route(router_id=router_id,agents=agents,external_subnet_id=external_subnet_id)
                        else:
                            logger.warning('please add gateway ip of router {}'.format(router_id))
                else:
                    logger.warning('please add internal interface to router {}'.format(router_id))

    def del_ip_route(self,router_id=None,router_ha=None,router_distributed=None):
        op = utils.OpenstackOperate(self.os_auth_file)
        router_detail = op.get_router_detail(router_id)
        if router_detail:
            external_gateway_ip = router_detail['router']['external_gateway_ip']
            external_subnet_id = router_detail['router']['external_subnet_id']
            agents = op.get_all_agents(router_id)
            cidrs = op.get_all_cidr(router_id)
            if agents and cidrs:
                if len(agents.values()) == 1 and router_ha == 'False' and router_distributed == 'False':
                    if external_gateway_ip:
                        for cidr in cidrs.values():
                            self.del_single_host_route(external_gateway_ip=external_gateway_ip,cidr=cidr,router_id=router_id)
                        self.del_single_router_ip_route(router_id=router_id,agents=agents,external_subnet_id=external_subnet_id)
                        return {'result':'true'}
                    else:
                        return {'result':'true'}
                elif len(agents) == 1 and router_ha == 'False' and router_distributed == 'True':
                    if external_gateway_ip:
                        for cidr in cidrs.values():
                            self.del_single_dvrhost_route(external_gateway_ip=external_gateway_ip, cidr=cidr,
                                                        router_id=router_id)
                        self.del_single_dvrrouter_ip_route(router_id=router_id,agents=agents)
                        return {'result':'true'}
                    else:
                        return {'result':'true'}
                elif len(agents) >= 1 and router_ha == 'True' and router_distributed == 'True':
                    if external_gateway_ip:
                        for cidr in cidrs.values():
                            self.del_multi_dvrhost_route(external_gateway_ip=external_gateway_ip,cidr=cidr,
                                                        router_id=router_id,agents=agents)
                        self.del_multi_dvrrouter_ip_route(router_id=router_id,agents=agents,external_subnet_id=external_subnet_id)
                        return {'result':'true'}
                    else:
                        return {'result':'true'}
            else:
                return {'result':'true'}
        else:
            return {'result':'true'}
    def get_org_cidrs(self):
        try:
            routers = self.scan_resource()
            if routers:
                for router in routers['routers']:
                    router_id = router['id']
                    op = utils.OpenstackOperate(self.os_auth_file)
                    router_detail = op.get_router_detail(router_id)
                    if router_detail:
                        external_gateway_ip = router_detail['router']['external_gateway_ip']
                    cidrs = op.get_all_cidr(router_id)
                    if cidrs:
                        if external_gateway_ip:
                           self.org_cidrs[router_id] = cidrs.values()
                           logger.info('org_cidrs of router {} is {}'.format(router_id,self.org_cidrs[router_id]))
                        else:
                            logger.warning('please add gateway ip of router {}'.format(router_id))
                    else:
                        logger.warning('please add internal interface to router {}'.format(router_id))
        except Exception,e:
            logger.warning(e)

    def sync_ip_route(self):
        try:
            routers = self.scan_resource()
            if routers:
                for router in routers['routers']:
                    router_id = router['id']
                    router_ha = router['ha']
                    router_distributed = router['distributed']
                    op = utils.OpenstackOperate(self.os_auth_file)
                    router_detail = op.get_router_detail(router_id)
                    if router_detail:
                        external_gateway_ip = router_detail['router']['external_gateway_ip']
                    agents = op.get_all_agents(router_id)
                    cidrs = op.get_all_cidr(router_id)
                    if agents and cidrs:
                        if len(agents.values()) == 1 and router_ha == 'False' and router_distributed == 'False':
                            if external_gateway_ip:
                                self.new_cidrs[router_id] = cidrs.values()
                                if self.org_cidrs.get(router_id,None):
                                    logger.info('new_cidrs of router {} is {}'.format(router_id,self.new_cidrs[router_id]))
                                    if self.new_cidrs[router_id] == self.org_cidrs[router_id]:
                                        logger.info('Router {} synchronous success'.format(router_id))
                                    elif self.new_cidrs[router_id] != self.org_cidrs[router_id]:
                                        for cidr in self.new_cidrs[router_id]:
                                            if cidr not in self.org_cidrs[router_id]:
                                                self.add_single_host_route(external_gateway_ip=external_gateway_ip,cidr=cidr,router_id=router_id)
                                        logger.info('Router {} synchronous success'.format(router_id))
                                        for cidr in self.org_cidrs[router_id]:
                                            if cidr not in self.new_cidrs[router_id]:
                                                self.del_single_host_route(external_gateway_ip=external_gateway_ip,cidr=cidr,router_id=router_id)
                                        logger.info('Router {} synchronous success'.format(router_id))
                                else:
                                    for cidr in self.new_cidrs[router_id]:
                                        self.add_single_host_route(external_gateway_ip=external_gateway_ip,cidr=cidr,router_id=router_id)
                                    logger.info('Router {} synchronous success'.format(router_id))
                            else:
                                logger.warning('Synchronous failed,because gateway ip of router {} is None'
                                               .format(router_id))
                        elif len(agents) == 1 and router_ha == 'False' and router_distributed == 'True':
                            if external_gateway_ip:
                                self.new_cidrs[router_id] = cidrs.values()
                                if self.org_cidrs.get(router_id,None):
                                    logger.info('new_cidrs of router {} is {}'.format(router_id,self.new_cidrs[router_id]))
                                    if self.new_cidrs[router_id] == self.org_cidrs[router_id]:
                                        logger.info('Router {} synchronous success'.format(router_id))
                                    elif self.new_cidrs[router_id] != self.org_cidrs[router_id]:
                                        for cidr in self.new_cidrs[router_id]:
                                            if cidr not in self.org_cidrs[router_id]:
                                                self.add_single_dvrhost_route(external_gateway_ip=external_gateway_ip,cidr=cidr,
                                                                              router_id=router_id)
                                        logger.info('Router {} synchronous success'.format(router_id))
                                        for cidr in self.org_cidrs[router_id]:
                                            if cidr not in self.new_cidrs[router_id]:
                                                self.del_single_dvrhost_route(external_gateway_ip=external_gateway_ip,cidr=cidr,
                                                                              router_id=router_id)
                                        logger.info('Router {} synchronous success'.format(router_id))
                                else:
                                    for cidr in self.new_cidrs[router_id]:
                                        self.add_single_dvrhost_route(external_gateway_ip=external_gateway_ip,cidr=cidr,router_id=router_id)
                                    logger.info('Synchronous success')
                            else:
                                logger.warning('Synchronous failed,because gateway ip of router {} is None'
                                               .format(router_id))
                        elif len(agents) >= 1 and router_ha == 'True' and router_distributed == 'True':
                            if external_gateway_ip:
                                self.new_cidrs[router_id] = cidrs.values()
                                if self.org_cidrs.get(router_id,None):
                                    logger.info('new_cidrs of router {} is {}'.format(router_id,self.new_cidrs[router_id]))
                                    if self.new_cidrs[router_id] == self.org_cidrs[router_id]:
                                        logger.info('Router {} synchronous success'.format(router_id))
                                    elif self.new_cidrs[router_id] != self.org_cidrs[router_id]:
                                        for cidr in self.new_cidrs[router_id]:
                                            if cidr not in self.org_cidrs[router_id]:
                                                self.add_multi_dvrhost_route(external_gateway_ip=external_gateway_ip,cidr=cidr,router_id=router_id,agents=agents)
                                        logger.info('Router {} synchronous success'.format(router_id))
                                        for cidr in self.org_cidrs[router_id]:
                                            if cidr not in self.new_cidrs[router_id]:
                                                self.del_multi_dvrhost_route(external_gateway_ip=external_gateway_ip,cidr=cidr,router_id=router_id,agents=agents)
                                        logger.info('Router {} synchronous success'.format(router_id))
                                else:
                                    for cidr in self.new_cidrs[router_id]:
                                        self.add_multi_dvrhost_route(external_gateway_ip=external_gateway_ip,cidr=cidr,router_id=router_id,agents=agents)
                            else:
                                logger.warning('Synchronous failed,because gateway ip of router {} is None'
                                               .format(router_id))
                    elif not self.new_cidrs.get(router_id,None):
                        if len(agents.values()) == 1 and router_ha == 'False' and router_distributed == 'False':
                            if external_gateway_ip:
                                if self.org_cidrs.get(router_id,None):
                                    for cidr in self.org_cidrs[router_id]:
                                        self.del_single_host_route(external_gateway_ip=external_gateway_ip,cidr=cidr,router_id=router_id)
                                    logger.info('Router {} synchronous success'.format(router_id))
                                else:
                                    logger.warning('Synchronous failed,because internal interface of router {} is None'.format(router_id))
                            else:
                                logger.warning('Synchronous failed,because internal interface and gateway ip of router {} is None'.format(router_id))
                        elif len(agents.values()) == 1 and router_ha == 'False' and router_distributed == 'True':
                            if external_gateway_ip:
                                if self.org_cidrs.get(router_id,None):
                                    for cidr in self.org_cidrs[router_id]:
                                        self.del_single_dvrhost_route(external_gateway_ip=external_gateway_ip,cidr=cidr,router_id=router_id)
                                    logger.info('Router {} synchronous success'.format(router_id))
                                else:
                                    logger.warning('Synchronous failed,because internal interface of router {} is None'.format(router_id))
                            else:
                                logger.warning('Synchronous failed,because internal interface and gateway ip of router {} is None'.format(router_id))
                        elif len(agents.values()) >= 1 and router_ha == 'True' and router_distributed == 'True':
                            if external_gateway_ip:
                                if self.org_cidrs.get(router_id,None):
                                    for cidr in self.org_cidrs[router_id]:
                                        self.del_multi_dvrhost_route(external_gateway_ip=external_gateway_ip,cidr=cidr,router_id=router_id,agents=agents)
                                    logger.info('Router {} synchronous success'.format(router_id))
                                else:
                                    logger.warning('Synchronous failed,because internal interface of router {} is None'.format(router_id))
                            else:
                                logger.warning('Synchronous failed,because internal interface and gateway ip of router {} is None'.format(router_id))
        except Exception,e:
            logger.warning(traceback.format_exc())

def start_wsgi_server():
    wsgi_server = WSGIService()
    wsgi_server.start()
    wsgi_server.wait()

def start_monitor_server():
    while True:
        try:
            monitor_server = MonitorService()
            monitor_server.add_ip_route()
            monitor_server.get_org_cidrs()
            time.sleep(10)
            monitor_server.sync_ip_route()
        except Exception,e:
            logger.error(e)

if __name__ == '__main__':

    """
     使用多线程启动wsgi与monitor服务
   """
    wsgi_thread = threading.Thread(target=start_wsgi_server)
    monitor_thread = threading.Thread(target=start_monitor_server)
    wsgi_thread.start()
    monitor_thread.start()
    wsgi_thread.join()
    monitor_thread.join()

    """
    使用多进程启动wsgi与monitor服务
   """
    # wsgi_process = multiprocessing.Process(target=start_wsgi_server)
    # monitor_process = multiprocessing.Process(target=start_monitor_server)
    # wsgi_process.start()
    # monitor_process.start()
    # wsgi_process.join()
    # monitor_process.join()
